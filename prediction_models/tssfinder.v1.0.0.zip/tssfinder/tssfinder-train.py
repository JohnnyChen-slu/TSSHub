#!/usr/bin/env python

import pandas as pd
from Bio import SeqIO
from subprocess import Popen, PIPE, STDOUT
import os
import click
import sys

CURR_DIR = os.path.dirname(os.path.realpath(__file__))

MYOP_PROM_BIN = os.path.join(CURR_DIR, "bin/cli/tssfinder-train")

def rev(seq):
    rev_fasta = []
    for i in reversed(seq):
        if i.upper() == 'A':
            rev_fasta.append('T')
        elif i.upper() == 'C':
            rev_fasta.append('G')
        elif i.upper() == 'G':
            rev_fasta.append('C')
        elif i.upper() == 'T':
            rev_fasta.append('A')
        else:
            rev_fasta.append(i.upper())
    return ''.join(rev_fasta)

def extract_fasta_to_train(chrm, start, tata, tss, max_size=5000):
    dists = []
    for i in range(50, 601, 50):
        dists += [i]*50
    dists = ['600']*(max_size-len(dists)) + list(reversed(dists))
    for idx, row in start.iterrows():
        if row['strand'] == '+':
            if row['begin'] - max_size + 1 < 0:
                a = 0
            else:
                a = row['begin'] - max_size + 1

            labels = []

            try:
                tata_pos = tata[tata['gene_name'] == row['gene_name']]['begin'].values[0]
                labels += ['PROMOTER#2']*(tata_pos-(row['begin'] - max_size) - 3)
                labels += ['TATA-3', 'TATA-2', 'TATA-1', 'TATA-0', 'TATA+1', 'TATA+2', 'TATA+3']
            except:
                tata_pos = -1

            try:
                tss_pos = tss[tss['gene_name'] == row['gene_name']]['begin'].values[0]
            except:
                pass

            if tata_pos > 0:
                labels += ['PROMOTER#1']*(tss_pos-tata_pos-7)
            else:
                labels += ['PROMOTER#2']*(tss_pos-(row['begin'] - max_size) - 3)
            labels += ['TSS-3', 'TSS-2', 'TSS-1', 'TSS-0', 'TSS+1', 'TSS+2', 'TSS+3']

            labels += ["5'UTR"]*(row['begin'] - tss_pos - 4)

            if len(labels) != len(dists):
                continue

            seq = list(zip(chrm[str(row['chr'])][a:row['begin']+1], dists, labels))
        else:
            if row['begin']+max_size > len(chrm[str(row['chr'])]):
                b = len(chrm[str(row['chr'])])
            else:
                b = row['begin']+max_size

            labels = []

            try:
                tata_pos = tata[tata['gene_name'] == row['gene_name']]['begin'].values[0]
                labels += ['PROMOTER#2']*((row['begin'] + max_size) - tata_pos - 3)
                labels += ['TATA-3', 'TATA-2', 'TATA-1', 'TATA-0', 'TATA+1', 'TATA+2', 'TATA+3']
            except:
                tata_pos = -1

            try:
                tss_pos = tss[tss['gene_name'] == row['gene_name']]['begin'].values[0]
            except:
                continue

            if tata_pos > 0:
                labels += ['PROMOTER#1']*(tata_pos-tss_pos-7)
            else:
                labels += ['PROMOTER#2']*((row['begin'] + max_size) - tss_pos - 3)
            labels += ['TSS-3', 'TSS-2', 'TSS-1', 'TSS-0', 'TSS+1', 'TSS+2', 'TSS+3']

            labels += ["5'UTR"]*(tss_pos - row['begin'] - 4)

            if len(labels) != len(dists):
                continue

            seq = list(zip(rev(chrm[str(row['chr'])][row['begin']:b]), dists, labels))

        seq[0] = ('NPROMOTER', 'NPROMOTER', 'BEGIN')
        seq[-1] = ('NPROMOTER', 'NPROMOTER', 'CDS/INTRON')
        yield row, seq


@click.command()
@click.option('--model', help='model directory')
@click.option('--start', help='start codons BED file')
@click.option('--tata', help='tata-box BED file')
@click.option('--tss', help='tss BED file')
@click.option('--genome', help='genome FASTA file')
@click.option('--max_seq_size', default=1500,help='maximum sequence size to be analysed')
def predict(model, start, tata, tss, genome, max_seq_size):
    start_file = start
    fasta_file = genome

    try:
        os.mkdir(model)
    except:
        print("Directory already exists")

    print("Reading files")
    start = pd.read_csv(start_file, sep="\t", names=['chr', 'begin', 'end', 'gene_name', 'score', 'strand'])
    tata = pd.read_csv(tata, sep="\t", names=['chr', 'begin', 'end', 'gene_name', 'score', 'strand'])
    tss = pd.read_csv(tss, sep="\t", names=['chr', 'begin', 'end', 'gene_name', 'score', 'strand'])

    print("Reading fasta")
    chrm = {}
    for f in SeqIO.parse(open(fasta_file), 'fasta'):
        name, sequence = f.id, str(f.seq)
        chrm[name] = sequence

    print("Generating traing set")
    p = Popen("{} -m {}".format(MYOP_PROM_BIN, model).split(), stdout=PIPE, stdin=PIPE)
    for gene, fasta in extract_fasta_to_train(chrm, start, tata, tss, max_size=max_seq_size):
        for n, d, l in fasta:
            p.stdin.write("{}\t{}\t{}\n".format(n, d, l).encode("ascii"))
        p.stdin.write("\n".encode("ascii"))

    print(p.communicate()[0].decode())


# predict('model', 'dataset/athaliana/start.bed', 'dataset/athaliana/tata.bed', 'dataset/athaliana/tss.bed', 'dataset/athaliana/tair10.fa', '.', 1500)

if __name__ == '__main__':
    predict()
